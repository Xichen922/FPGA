param(
    [Parameter(Mandatory=$true)][string]$JavaHome,
    [Parameter(Mandatory=$true)][string]$BuildTools,
    [Parameter(Mandatory=$true)][string]$AndroidJar,
    [string]$BuildDir=(Join-Path $PSScriptRoot 'build')
)
$ErrorActionPreference='Stop'
function Run-Native([string]$Exe,[string[]]$Arguments){ & $Exe @Arguments; if($LASTEXITCODE -ne 0){throw "Command failed: $Exe"} }
$BuildDir=[IO.Path]::GetFullPath($BuildDir)
$originalSrc=Join-Path $PSScriptRoot 'app\src\main'
$src=Join-Path $BuildDir 'stage'
$classes=Join-Path $BuildDir 'classes'
$dex=Join-Path $BuildDir 'dex'
New-Item -ItemType Directory -Path $BuildDir,$classes,$dex,$src -Force | Out-Null
if($BuildDir -match '[^\x00-\x7F]'){throw 'BuildDir must use an ASCII-only path for Windows aapt2. Pass -BuildDir C:\build\b42.'}
Get-ChildItem -LiteralPath $originalSrc | Copy-Item -Destination $src -Recurse -Force
$java=Join-Path $JavaHome 'bin\java.exe'
$javac=Join-Path $JavaHome 'bin\javac.exe'
$jar=Join-Path $JavaHome 'bin\jar.exe'
$aapt=Join-Path $BuildTools 'aapt2.exe'
$sources=@(Get-ChildItem -LiteralPath (Join-Path $src 'java') -Recurse -Filter '*.java' | ForEach-Object {$_.FullName})
Run-Native $javac (@('--release','8','-encoding','UTF-8','-classpath',$AndroidJar,'-d',$classes)+$sources)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$classesJar=Join-Path $BuildDir 'classes.jar'
if(Test-Path -LiteralPath $classesJar){Remove-Item -LiteralPath $classesJar}
[IO.Compression.ZipFile]::CreateFromDirectory($classes,$classesJar)
Run-Native $java @('-cp',(Join-Path $BuildTools 'lib\d8.jar'),'com.android.tools.r8.D8','--lib',$AndroidJar,'--min-api','26','--output',$dex,(Join-Path $BuildDir 'classes.jar'))
Run-Native $aapt @('compile','--dir',(Join-Path $src 'res'),'-o',(Join-Path $BuildDir 'resources.zip'))
$base=Join-Path $BuildDir 'unaligned.apk'
Run-Native $aapt @('link','-o',$base,'--manifest',(Join-Path $src 'AndroidManifest.xml'),'-I',$AndroidJar,'--min-sdk-version','26','--target-sdk-version','35','--auto-add-overlay',(Join-Path $BuildDir 'resources.zip'))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open($base,[IO.Compression.ZipArchiveMode]::Update)
try{
    foreach($f in Get-ChildItem -LiteralPath $dex -Filter '*.dex'){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    $assetsRoot=Join-Path $src 'assets'
    foreach($f in Get-ChildItem -LiteralPath $assetsRoot -File -Recurse){
        $relative=$f.FullName.Substring($assetsRoot.Length).TrimStart([char[]]"\/").Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,('assets/'+$relative),[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    $catalog=Get-Content -LiteralPath (Join-Path $assetsRoot 'catalog.json') -Raw|ConvertFrom-Json
    foreach($item in $catalog){if($null -eq $zip.GetEntry('assets/'+$item.asset)){throw ('Missing packaged asset: '+$item.asset)}}
    foreach($entry in $zip.Entries){if($entry.FullName.Contains('\')){throw ('Noncanonical ZIP path: '+$entry.FullName)}}
}finally{$zip.Dispose()}
Run-Native (Join-Path $BuildTools 'zipalign.exe') @('-f','4',$base,(Join-Path $BuildDir 'aligned.apk'))
$key=Join-Path $PSScriptRoot 'test-signing.jks'
if(!(Test-Path -LiteralPath $key)){Run-Native (Join-Path $JavaHome 'bin\keytool.exe') @('-genkeypair','-keystore',$key,'-storepass','android','-keypass','android','-alias','b42test','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=B42 Local Test,O=Local Development,C=CN')}
$apk=Join-Path $BuildDir 'BluetoothScore-0.7.1.apk'
Run-Native $java @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'sign','--ks',$key,'--ks-pass','pass:android','--key-pass','pass:android','--out',$apk,(Join-Path $BuildDir 'aligned.apk'))
Run-Native $java @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'verify','--verbose',$apk)
Write-Output $apk
