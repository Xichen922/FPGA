$ErrorActionPreference = 'Stop'
$sdkRoot = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$javaHome = if ($env:JAVA_HOME) { $env:JAVA_HOME } else { Join-Path $env:ProgramFiles 'Android\Android Studio\jbr' }
$buildTools = Join-Path $sdkRoot 'build-tools\36.0.0'
$androidJar = Join-Path $sdkRoot 'platforms\android-35\android.jar'
$buildDir = Join-Path $env:TEMP 'B42Build071'

foreach ($item in @(
    @{ Path = (Join-Path $javaHome 'bin\javac.exe'); Help = '请安装 Android Studio 的 JDK，或设置 JAVA_HOME。' },
    @{ Path = (Join-Path $buildTools 'aapt2.exe'); Help = '请在 Android Studio SDK Manager 安装 Build-Tools 36.0.0。' },
    @{ Path = $androidJar; Help = '请在 Android Studio SDK Manager 安装 Android API 35。' }
)) {
    if (-not (Test-Path -LiteralPath $item.Path)) { throw "$($item.Help) 缺少：$($item.Path)" }
}

& (Join-Path $PSScriptRoot 'build.ps1') -JavaHome $javaHome -BuildTools $buildTools -AndroidJar $androidJar -BuildDir $buildDir
if (-not $?) { throw 'APK 构建失败，请查看上面的错误。' }
$sourceApk = Join-Path $buildDir 'BluetoothScore-0.7.1.apk'
if (-not (Test-Path -LiteralPath $sourceApk)) { throw "没有生成 APK：$sourceApk" }
$targetApk = Join-Path $PSScriptRoot 'BluetoothScore-0.7.1.apk'
Copy-Item -LiteralPath $sourceApk -Destination $targetApk -Force
Write-Output "APK 已生成：$targetApk"
