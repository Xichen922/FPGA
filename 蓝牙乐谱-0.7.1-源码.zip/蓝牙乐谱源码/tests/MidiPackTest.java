package cn.b42.music;
import java.nio.file.*;
import java.util.*;
public final class MidiPackTest {
    public static void main(String[] args)throws Exception{
        int files=0,parts=0,ready=0;List<Path> paths=new ArrayList<>();try(java.util.stream.Stream<Path> stream=Files.list(Paths.get(args[0]))){stream.filter(p->p.toString().endsWith(".mid")).sorted().forEach(paths::add);}
        for(Path p:paths){Midi m=Midi.read(Files.readAllBytes(p));files++;if(!p.getFileName().toString().contains("适配"))continue;
            for(Midi.Note n:m.notes)if(n.pitch<48||n.pitch>83)throw new AssertionError("adapted note out of range: "+p);
            Converter.Options o=new Converter.Options();for(int i=0;i<m.tracks.size();i++)if(!m.tracks.get(i).percussionOnly&&m.tracks.get(i).count>0)o.tracks.add(i);
            Converter.Result r=Converter.convert(m,o);if(p.getFileName().toString().matches(".*_第[0-9]+段\\.mid")){parts++;if(!r.ready())throw new AssertionError("segment did not pass: "+p+" "+r.errors);}if(r.ready())ready++;
            System.out.println(p.getFileName()+" | notes="+m.notes.size()+" | events="+r.entries.size()+" | "+(r.ready()?"READY":String.join(";",r.errors)));
        }
        System.out.println("SUMMARY parsed="+files+" segmented="+parts+" adaptedReady="+ready);
    }
}
