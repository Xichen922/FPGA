"""Verify the actual APK, not just the source asset directory."""
import sys, json, zipfile, struct
from pathlib import Path
apk=Path(sys.argv[1])
source=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[1]/'app/src/main/assets'
with zipfile.ZipFile(apk) as z:
    # Check raw central-directory names: some Windows Python builds normalize
    # backslashes during reading, hiding the exact bug Android encounters.
    data=apk.read_bytes();offset=z.start_dir;names=set()
    while data[offset:offset+4]==b'PK\x01\x02':
        length,extra,comment=struct.unpack_from('<HHH',data,offset+28)
        raw=data[offset+46:offset+46+length]
        names.add(raw.decode('utf-8'))
        offset+=46+length+extra+comment
    bad=[n for n in names if '\\' in n]
    if bad: raise AssertionError('Noncanonical ZIP paths: '+repr(bad[:3]))
    catalog=json.loads(z.read('assets/catalog.json'))
    for item in catalog:
        raw=z.read('assets/'+item['asset'])
        assert raw.startswith(b'MThd'), item['asset']
        assert raw==(source/item['asset']).read_bytes(), item['asset']
    count=0
    for p in source.rglob('*'):
        if p.is_file():
            name='assets/'+p.relative_to(source).as_posix()
            assert z.read(name)==p.read_bytes(), name
            count+=1
    assert 'assets/catalog/m005.mid' in names
print(f'PASS APK: {len(catalog)} catalog MIDIs + all {count} asset files match source, forward-slash paths only')
