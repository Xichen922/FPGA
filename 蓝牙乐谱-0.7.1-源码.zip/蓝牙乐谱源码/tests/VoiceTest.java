package cn.b42.music;
import java.nio.file.*;import java.util.*;
public final class VoiceTest {
    static int checks;
    static void check(boolean b,String msg){checks++;if(!b)throw new AssertionError(msg);}
    public static void main(String[] args)throws Exception{
        Midi m=new Midi();Midi.Track a=new Midi.Track(),b=new Midi.Track();a.name="Accompaniment";a.count=1000;a.percussionOnly=false;b.name="Melody";b.count=10;b.percussionOnly=false;m.tracks.add(a);m.tracks.add(b);check(TrackSelection.recommend(m)==1,"dense accompaniment cannot override explicit melody");
        int files=0;try(java.util.stream.Stream<Path> st=Files.list(Paths.get(args[0]))){for(Path f:(Iterable<Path>)st.filter(p->p.toString().endsWith("适配C3-B5.mid")||p.getFileName().toString().matches(".*适配C3-B5_第[0-9]+段\\.mid"))::iterator){
            Midi src=Midi.read(Files.readAllBytes(f));int tr=TrackSelection.recommend(src);if(src.tracks.get(1).count==0){check(tr==-1,"empty melody never falls back to accompaniment");System.out.println("NO MELODY: "+f.getFileName());files++;continue;}check(tr>=0&&src.tracks.get(tr).name.equals("Melody"),"named melody preferred "+f);
            String name=f.getFileName().toString().replace(".mid","_仅主旋律.mid");Midi pure=Midi.read(Files.readAllBytes(Paths.get(args[1],name)));List<Midi.Note> expected=new ArrayList<>();for(Midi.Note n:src.notes)if(n.track==tr)expected.add(n);
            check(expected.size()==pure.notes.size(),"pure note count "+f);for(int i=0;i<expected.size();i++){Midi.Note n=expected.get(i),p=pure.notes.get(i);check(n.pitch==p.pitch&&Math.abs(n.startMs-p.startMs)<.001&&Math.abs(n.endMs-p.endMs)<.001,"pitch/timing unchanged "+f);}
            files++;
        }}check(files==55,"all 55 exports checked");
        Midi corrected=Midi.read(Files.readAllBytes(Paths.get(args[2])));int[] pitches={72,71,64,69,67,64,62,60,57,62,64,57};check(corrected.notes.size()==12,"checked four bars 12 notes");for(int i=0;i<pitches.length;i++)check(corrected.notes.get(i).pitch==pitches[i],"checked pitch "+i);check(Math.abs(corrected.notes.get(2).endMs-1333.334)<1,"bar1 eighths");check(Math.abs(corrected.durationMs-5333.336)<1,"four bars two quarters each");
        Converter.Options o=new Converter.Options();o.tracks.add(1);Converter.Result r=Converter.convert(corrected,o);check(r.ready()&&r.entries.stream().allMatch(e->Integer.bitCount(e.mask)<=1),"corrected excerpt yields only single-key melody");
        System.out.println("PASS "+checks+" voice/export/checked-excerpt checks");
    }
}
