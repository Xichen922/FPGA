"""Create a small original two-track MIDI fixture; no external packages needed."""
import struct
from pathlib import Path
import sys

def vlq(value):
    out = [value & 127]
    while value >> 7:
        value >>= 7
        out.insert(0, (value & 127) | 128)
    return bytes(out)

def chunk(name, content):
    return name + struct.pack('>I', len(content)) + content

def track(name, events):
    label = name.encode('utf-8')
    data = b'\0\xff\x03' + vlq(len(label)) + label
    last = 0
    for tick, event in sorted(events, key=lambda item: item[0]):
        data += vlq(tick - last) + bytes(event)
        last = tick
    return chunk(b'MTrk', data + b'\0\xff\x2f\0')

def generate(path):
    header = chunk(b'MThd', struct.pack('>HHH', 1, 3, 480))
    tempo = track('速度 120 BPM', [(0, [255, 81, 3, 7, 161, 32]), (1440, [255, 1, 0])])
    lead = track('C4 与 E4', [(0, [144, 60, 100]), (960, [128, 60, 0]), (960, [144, 64, 100]), (1440, [128, 64, 0])])
    upper = track('B5 持续音（请同时勾选）', [(480, [145, 83, 100]), (1440, [129, 83, 0])])
    Path(path).write_bytes(header + tempo + lead + upper)

if __name__ == '__main__':
    generate(sys.argv[1])
