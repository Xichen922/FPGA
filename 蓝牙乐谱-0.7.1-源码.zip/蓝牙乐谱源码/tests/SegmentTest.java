package cn.b42.music;
import java.nio.file.*;import java.util.*;
public final class SegmentTest {
    static int checks;
    static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
    static Midi song(int n,boolean held){Midi m=new Midi();Midi.Track t=new Midi.Track();t.name="Melody";t.count=n;t.percussionOnly=false;m.tracks.add(t);for(int i=0;i<n;i++)m.notes.add(new Midi.Note(i,0,0,held?64+i%2:60+i%2,100,i*100,i*100+50));m.durationMs=n*100;if(held)m.notes.add(new Midi.Note(n,0,0,60,100,0,m.durationMs));return m;}
    static Converter.Options options(){Converter.Options o=new Converter.Options();o.tracks.add(0);return o;}
    static void verify(Midi m,Converter.Options o,SegmentPlanner.Plan p){check(p.ready(),"plan ready: "+p.errors);double cursor=o.startSec;for(SegmentPlanner.Part part:p.parts){check(Math.abs(cursor-part.startSec)<.000001,"no gap or overlap");check(part.endSec>part.startSec,"positive duration");check(part.result.ready()&&part.result.entries.size()<=512,"capacity independently verified");Converter.Result again=Converter.convert(m,SegmentPlanner.copy(o,part.startSec,part.endSec));check(again.ready()&&again.entries.size()==part.result.entries.size(),"rerun matches preview count");cursor=part.endSec;}check(Math.abs(cursor-(o.endSec>0?o.endSec:m.durationMs/1000))<.000001,"tail covered");}
    public static void main(String[] args)throws Exception{
        Converter.Options o=options();Midi m=song(600,false);SegmentPlanner.Plan p=SegmentPlanner.plan(m,o);verify(m,o,p);check(p.parts.size()>1,"long score split");for(SegmentPlanner.Part part:p.parts)check(!part.heldAtStart&&!part.heldAtEnd,"natural breaks preferred");
        m=song(10,false);p=SegmentPlanner.plan(m,o);verify(m,o,p);check(p.parts.size()==1,"small score stays whole");
        m=song(650,true);p=SegmentPlanner.plan(m,o);verify(m,o,p);check(p.parts.size()>1&&p.parts.get(0).heldAtEnd&&p.parts.get(1).heldAtStart,"sustained voice breaks explicitly flagged");
        o.speed=.75;o.startSec=1.25;o.endSec=50.25;m=song(600,false);p=SegmentPlanner.plan(m,o);verify(m,o,p);check(o.startSec==1.25&&o.endSec==50.25&&o.speed==.75,"caller options unchanged");
        m=song(600,false);m.notes.get(0).pitch=40;p=SegmentPlanner.plan(m,options());check(!p.ready()&&p.parts.isEmpty(),"pitch error not hidden by segmentation");
        o=options();o.startSec=2;o.endSec=1;p=SegmentPlanner.plan(song(100,false),o);check(!p.ready()&&!p.errors.isEmpty(),"bad range explicit failure");
        Midi real=Midi.read(Files.readAllBytes(Paths.get(args[0])));o=options();o.tracks.clear();o.tracks.add(TrackSelection.recommend(real));Converter.Result full=Converter.convert(real,o);check(full.capacityExceeded&&!full.ready(),"real Buran whole exceeds 512");p=SegmentPlanner.plan(real,o);verify(real,o,p);check(p.parts.size()==2,"real Buran has two suggested parts");for(SegmentPlanner.Part part:p.parts)System.out.printf(Locale.ROOT,"Buran %.6f--%.6f sec: %d entries%n",part.startSec,part.endSec,part.result.entries.size());
        System.out.println("PASS "+checks+" segment checks");
    }
}
