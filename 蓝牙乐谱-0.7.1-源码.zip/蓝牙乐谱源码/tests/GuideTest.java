package cn.b42.music;
import java.io.*;
import java.util.*;
public final class GuideTest {
    static int checks;
    static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
    static class Board implements Session.Link {
        List<String> sent=new ArrayList<>();ArrayDeque<String> replies=new ArrayDeque<>();int n;boolean old,closed,badCount,dropGuide,simpleSupported;String state="idle";
        public void write(String s){sent.add(s);if(s.equals("V\n"))replies.add("V=042");else if(s.equals("S\n")){state="idle";replies.add("K");}else if(s.equals("C\n")){n=0;state="idle";replies.add("K");}else if(s.startsWith("M")){n++;replies.add("K");}else if(s.equals("?\n"))replies.add(String.format(Locale.ROOT,"N=%03d",badCount&&n>0?n-1:n));else if(s.equals("H\n")){if(simpleSupported){state="simple";replies.add("K");}else replies.add("E");}else if(s.equals("G\n")){if(dropGuide)return;if(old)replies.add("E");else{state="guide";replies.add(n==0?"Z":"K");}}else if(s.equals("P\n")){state="auto";replies.add("K");}}
        public String read(long ms){return replies.poll();}public void close(){closed=true;}
    }
    public static void main(String[] args)throws Exception{
        List<Score.Entry> score=Arrays.asList(new Score.Entry(1,50,4,-1,-1),new Score.Entry(0,10,4,-1,-1),new Score.Entry(4,50,4,-1,-1));
        Board b=new Board();Session s=new Session(b);s.verify();s.uploadAndGuide(score,(x,y)->{});
        check(b.state.equals("guide")&&!b.sent.contains("P\n"),"guide upload never auto-plays");check(b.sent.indexOf("S\n")<b.sent.indexOf("C\n"),"stop before clearing/uploading");check(b.sent.get(b.sent.size()-2).equals("?\n"),"count checked before G");s.guide();check(b.sent.get(b.sent.size()-1).equals("G\n"),"restart guide from beginning");s.stop();check(b.state.equals("idle"),"stop guide");s.play();check(b.state.equals("auto"),"switch to auto play without reupload");
        b=new Board();b.old=true;s=new Session(b);s.verify();try{s.uploadAndGuide(score,(x,y)->{});throw new AssertionError("old guide accepted");}catch(Session.GuideUnsupportedException expected){check(s.uploaded&&s.verified&&!b.closed,"G rejected preserves uploaded song and connection");check(!b.sent.contains("P\n"),"no surprise auto fallback");}s.play();check(b.state.equals("auto"),"user can choose auto after unsupported G");
        b=new Board();b.badCount=true;s=new Session(b);s.verify();try{s.uploadAndGuide(score,(x,y)->{});throw new AssertionError("bad count accepted");}catch(IOException expected){check(!b.sent.contains("G\n")&&b.closed,"mismatch blocks guide");}
        b=new Board();b.dropGuide=true;s=new Session(b);s.verify();try{s.uploadAndGuide(score,(x,y)->{});throw new AssertionError("G timeout accepted");}catch(IOException expected){check(b.closed&&!s.uploaded,"G timeout invalidates and closes uncertain session");}
        b=new Board();s=new Session(b);s.verify();final Session canceled=s;try{s.uploadAndGuide(score,(x,y)->canceled.cancel.set(true));throw new AssertionError("cancel accepted");}catch(InterruptedIOException expected){check(!b.sent.contains("G\n")&&!b.sent.contains("P\n"),"cancel never starts either mode");}
        b=new Board();b.simpleSupported=true;s=new Session(b);s.verify();s.uploadAndGuide(score,(x,y)->{},true);check(b.state.equals("simple")&&!b.sent.contains("G\n")&&!b.sent.contains("P\n"),"simple emits only proposed H start");s.guide(true);check(b.sent.get(b.sent.size()-1).equals("H\n"),"simple restart uses same mode");
        b=new Board();s=new Session(b);s.verify();try{s.uploadAndGuide(score,(x,y)->{},true);throw new AssertionError("B44 accepted H");}catch(Session.GuideUnsupportedException expected){check(expected.getMessage().contains("简单")&&s.verified&&s.uploaded&&!b.closed,"old B44 H rejection keeps connection and score");check(!b.sent.contains("G\n")&&!b.sent.contains("P\n"),"no silent simple fallback");}
        s.guide(false);check(b.state.equals("guide"),"explicit normal mode works after rejected simple");
        check(!TaskFailurePolicy.disconnect(false,new FileNotFoundException("catalog/m005.mid")),"missing asset keeps Bluetooth");
        check(!TaskFailurePolicy.disconnect(false,new IOException("local save failed")),"local write failure keeps Bluetooth");
        check(TaskFailurePolicy.disconnect(true,new IOException("socket failed")),"device IO failure disconnects");
        check(!TaskFailurePolicy.disconnect(true,new Session.GuideUnsupportedException(true)),"unsupported capability stays connected");
        check(!TaskFailurePolicy.disconnect(true,new InterruptedIOException("cancel")),"cancel is not link failure");
        check(!TaskFailurePolicy.disconnect(true,new IllegalArgumentException("invalid options")),"bad options do not break link");
        System.out.println("PASS "+checks+" guide/failure-policy checks");
    }
}
