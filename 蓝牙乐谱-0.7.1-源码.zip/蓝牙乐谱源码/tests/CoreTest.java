package cn.b42.music;

import java.io.*;
import java.util.*;

public final class CoreTest {
    static int checks;
    static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
    static Midi song(Midi.Note...notes){Midi m=new Midi();Midi.Track t=new Midi.Track();t.name="Test";t.percussionOnly=false;m.tracks.add(t);for(Midi.Note n:notes){m.notes.add(n);t.count++;m.durationMs=Math.max(m.durationMs,n.endMs);}return m;}
    static Midi.Note note(int id,int p,double a,double b){return new Midi.Note(id,0,0,p,100,a,b);}
    static Converter.Options opts(){Converter.Options o=new Converter.Options();o.tracks.add(0);return o;}
    static byte[] chunk(String name,byte[] data)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);d.writeBytes(name);d.writeInt(data.length);d.write(data);return b.toByteArray();}
    static byte[] midiFixture()throws Exception{
        // Two tracks. Quarter 1 = 500 ms, quarter 2 = 250 ms. Running status + note-on velocity zero.
        ByteArrayOutputStream f=new ByteArrayOutputStream();f.write(chunk("MThd",new byte[]{0,1,0,2,1,(byte)0xe0}));
        f.write(chunk("MTrk",new byte[]{0,(byte)0xff,0x51,3,7,(byte)0xa1,0x20,(byte)0x83,0x60,(byte)0xff,0x51,3,3,(byte)0xd0,(byte)0x90,(byte)0x83,0x60,(byte)0xff,0x2f,0}));
        f.write(chunk("MTrk",new byte[]{0,(byte)0xff,3,4,'L','e','a','d',0,(byte)0x90,60,100,(byte)0x83,0x60,60,0,0,64,100,(byte)0x83,0x60,(byte)0x80,64,0,0,(byte)0xff,0x2f,0}));return f.toByteArray();
    }
    static final class Fake implements Session.Link {
        List<String> writes=new ArrayList<>();ArrayDeque<String> replies=new ArrayDeque<>();int count,append;boolean lost,closed,cancel,badVersion,full,badCount;Session owner;
        public void write(String s){writes.add(s);if(s.equals("V\n"))replies.add(badVersion?"E":"V=042");else if(s.equals("C\n")){count=0;replies.add("K");}else if(s.equals("?\n"))replies.add(String.format(Locale.ROOT,"N=%03d",badCount&&append>0?count-1:count));else if(s.startsWith("M")||s.matches("[0-9].*\\n")){append++;if(full){replies.add("F");return;}count++;if(!lost||append!=1)replies.add("K");if(cancel)owner.cancel.set(true);}else if(s.equals("P\n")||s.equals("S\n"))replies.add("K");}
        public String read(long t){return replies.poll();}public void close(){closed=true;}
    }
    static void converterTests(){
        Converter.Result r=Converter.convert(song(note(0,60,0,1000),note(1,83,500,1000)),opts());
        check(r.ready(),"cross-octave converts");check(r.entries.size()==2,"two snapshots");check(r.entries.get(0).mask==1&&r.entries.get(0).octave==4,"C4 starts");check(r.entries.get(1).mask==0x801&&r.entries.get(1).octave==5,"C4 held while B5 starts");check(r.entries.stream().mapToInt(e->e.units).sum()==100,"timeline stays 1000 ms");
        r=Converter.convert(song(note(0,60,0,500),note(1,64,0,500),note(2,83,0,500)),opts());check(r.ready(),"same beat split");check(r.delayed>0,"stagger warning");check(r.entries.stream().mapToInt(e->e.units).sum()==50,"split subtracts time");check(r.entries.get(r.entries.size()-1).mask==0x811,"all notes present");
        r=Converter.convert(song(note(0,60,0,500),note(1,60,500,1000),note(2,64,0,1000)),opts());check(r.ready(),"repeated notes playable");check(r.entries.stream().anyMatch(e->e.mask==0x10&&e.units>=2),"only C released >=20ms, E held");
        r=Converter.convert(song(note(0,48,0,500),note(1,60,0,500),note(2,64,0,500)),opts());check(r.ready()&&r.simplified==1,"same-key higher octave wins");
        r=Converter.convert(song(note(0,60,0,30000)),opts());check(r.ready()&&r.entries.size()==4,"long hold split");check(r.entries.stream().allMatch(e->e.mask==1),"long hold continuous");
        r=Converter.convert(song(note(0,47,0,500)),opts());check(!r.ready()&&!r.errors.isEmpty(),"out of range blocks");
        r=Converter.convert(song(note(0,60,0,10),note(1,83,0,10)),opts());check(!r.ready(),"too-short cross group blocks, no silent lost note");
        Midi many=new Midi();Midi.Track t=new Midi.Track();many.tracks.add(t);for(int i=0;i<600;i++)many.notes.add(note(i,60+i%2,i*100,i*100+50));many.durationMs=60000;r=Converter.convert(many,opts());check(!r.ready()&&r.entries.size()>512,"capacity measured after conversion");
        Converter.Options clip=opts();clip.startSec=.25;clip.endSec=.75;r=Converter.convert(song(note(0,60,0,1000)),clip);check(r.ready()&&r.entries.get(0).units==50,"clip keeps held intersection");
        r=Converter.convert(song(),opts());check(!r.ready(),"empty score blocks");
    }
    public static void main(String[] args)throws Exception{
        Midi m=Midi.read(midiFixture());check(m.tracks.size()==2&&m.notes.size()==2,"multitrack parser");check(m.tracks.get(1).name.equals("Lead"),"track names");check(Math.abs(m.notes.get(0).endMs-500)<.001&&Math.abs(m.notes.get(1).endMs-750)<.001,"tempo map + running status");
        try{Midi.read(new byte[]{0,1,2});throw new AssertionError("invalid accepted");}catch(IOException ok){checks++;}
        try{Midi.read(Arrays.copyOf(midiFixture(),25));throw new AssertionError("truncation accepted");}catch(IOException ok){checks++;}
        byte[] smpte=midiFixture();smpte[12]=(byte)0xe8;try{Midi.read(smpte);throw new AssertionError("SMPTE accepted");}catch(IOException ok){checks++;}
        ByteArrayOutputStream sustainFile=new ByteArrayOutputStream();sustainFile.write(chunk("MThd",new byte[]{0,0,0,1,1,(byte)0xe0}));sustainFile.write(chunk("MTrk",new byte[]{0,(byte)0x90,60,100,0,(byte)0xb0,64,127,(byte)0x83,0x60,(byte)0x80,60,0,(byte)0x83,0x60,(byte)0xb0,64,0,0,(byte)0xff,0x2f,0}));Midi sm=Midi.read(sustainFile.toByteArray());check(Math.abs(sm.notes.get(0).endMs-1000)<.001,"sustain pedal release respected");
        converterTests();
        List<Score.Entry> data=Arrays.asList(new Score.Entry(1,50,4,-1,-1),new Score.Entry(0x801,50,5,-1,-1));
        Fake f=new Fake();Session s=new Session(f);s.verify();s.uploadAndPlay(data,(a,b)->{});check(s.uploaded&&f.count==2,"upload verified");check(f.writes.get(f.writes.size()-2).equals("?\n")&&f.writes.get(f.writes.size()-1).equals("P\n"),"query before play");
        f=new Fake();f.lost=true;s=new Session(f);s.verify();try{s.uploadAndPlay(data,(a,b)->{});throw new AssertionError("lost reply accepted");}catch(IOException ok){check(f.append==1&&f.count==1,"uncertain append never resent");check(f.closed&&!s.uploaded&&!f.writes.contains("P\n"),"timeout closes, never plays");}
        f=new Fake();f.cancel=true;s=new Session(f);f.owner=s;s.verify();try{s.uploadAndPlay(data,(a,b)->{});throw new AssertionError("cancel ignored");}catch(InterruptedIOException ok){check(f.append==1&&f.writes.contains("S\n")&&!f.writes.contains("P\n"),"cancel stops after current ACK");}
        f=new Fake();f.badVersion=true;s=new Session(f);try{s.verify();throw new AssertionError("old firmware accepted");}catch(IOException ok){check(!s.verified,"old firmware blocked");}
        f=new Fake();f.full=true;s=new Session(f);s.verify();try{s.uploadAndPlay(data,(a,b)->{});throw new AssertionError("full accepted");}catch(IOException ok){check(f.append==1&&!f.writes.contains("P\n"),"full stops immediately");}
        f=new Fake();f.badCount=true;s=new Session(f);s.verify();try{s.uploadAndPlay(data,(a,b)->{});throw new AssertionError("bad count accepted");}catch(IOException ok){check(!f.writes.contains("P\n"),"count mismatch never plays");}
        f=new Fake();s=new Session(f);s.verify();List<Score.Entry> fullScore=new ArrayList<>();for(int i=0;i<512;i++)fullScore.add(data.get(0));s.uploadAndPlay(fullScore,(a,b)->{});check(f.count==512&&s.uploaded,"512th event accepted");
        fullScore.add(data.get(0));try{s.uploadAndPlay(fullScore,(a,b)->{});throw new AssertionError("513 accepted");}catch(IOException ok){checks++;}
        try{Score.parseAscii("M001,000\n");throw new AssertionError("zero duration accepted");}catch(IllegalArgumentException ok){checks++;}
        List<Score.Entry> regression=Score.parseAscii(new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(args[0])),"UTF-8"));check(regression.size()==415,"huanzhou has 415 events");check(regression.stream().mapToInt(e->e.units).sum()==19000,"huanzhou 190s nominal");
        // The app must transmit the original legacy lines for this regression.
        check(regression.get(0).legacy!=null,"legacy regression encoding preserved");
        f=new Fake();s=new Session(f);s.verify();s.uploadAndPlay(regression,(a,b)->{});check(f.writes.get(f.writes.size()-1).equals("P\n"),"legacy fixture passes upload state machine");
        if(args.length>1){Midi sample=Midi.read(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(args[1])));Converter.Options selected=new Converter.Options();selected.tracks.add(1);selected.tracks.add(2);Converter.Result cr=Converter.convert(sample,selected);check(cr.ready()&&cr.entries.stream().anyMatch(e->e.mask==0x801&&e.octave==5),"delivered sample MIDI cross-octave conversion");}
        System.out.println("PASS "+checks+" core checks");
    }
}
