package cn.b42.music;
import java.io.*;
/** File/parse/save failures cannot invalidate an unrelated Bluetooth session. */
public final class TaskFailurePolicy {
    public static boolean disconnect(boolean deviceOperation,Exception error){
        return deviceOperation&&error instanceof IOException&&!(error instanceof InterruptedIOException)&&!(error instanceof Session.GuideUnsupportedException);
    }
}
