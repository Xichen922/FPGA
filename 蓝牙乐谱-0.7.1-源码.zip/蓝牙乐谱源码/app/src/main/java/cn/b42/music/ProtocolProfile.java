package cn.b42.music;
import java.io.IOException;

/** Capabilities are selected by a successful device handshake, never a user guess. */
public final class ProtocolProfile {
    public static final ProtocolProfile LEGACY=new ProtocolProfile("042",512,3,2500,2500);
    public static final ProtocolProfile FLASH48=new ProtocolProfile("048",8192,4,20000,3500);
    public final String version;public final int capacity,countDigits;public final long clearTimeoutMs,eventTimeoutMs;
    private ProtocolProfile(String v,int c,int d,long clear,long event){version=v;capacity=c;countDigits=d;clearTimeoutMs=clear;eventTimeoutMs=event;}
    public static ProtocolProfile fromReply(String s)throws IOException{if("V=042".equals(s))return LEGACY;if("V=048".equals(s))return FLASH48;throw new IOException("不支持的协议版本："+s+"；需要 V=042 或 V=048");}
    public int count(String s)throws IOException{if(s==null||!s.matches("N=[0-9]{"+countDigits+"}"))throw new IOException("数量回复格式与协议 "+version+" 不符："+s);int n=Integer.parseInt(s.substring(2));if(n>capacity)throw new IOException("板端数量超过 "+capacity+" 条");return n;}
}
