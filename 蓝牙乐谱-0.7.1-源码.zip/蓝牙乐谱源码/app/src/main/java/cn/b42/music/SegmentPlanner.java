package cn.b42.music;
import java.util.*;

/** Suggest complete source-time partitions; convert every part independently. No Bluetooth I/O. */
public final class SegmentPlanner {
    public static final class Part {
        public final double startSec,endSec;public final Converter.Result result;public final boolean heldAtStart,heldAtEnd;
        public Part(double a,double b,Converter.Result r,boolean hs,boolean he){startSec=a;endSec=b;result=r;heldAtStart=hs;heldAtEnd=he;}
        public String boundary(){return heldAtEnd?"断点仍有持续音：下一段将重新起音":"休止 / 换音边界：没有跨断点持续音";}
    }
    public static final class Plan {public final List<Part> parts=new ArrayList<>();public final List<String> errors=new ArrayList<>();public boolean ready(){return errors.isEmpty()&&!parts.isEmpty();}}
    public static Converter.Options copy(Converter.Options o,double start,double end){Converter.Options x=new Converter.Options();x.capacity=o.capacity;x.tracks.addAll(o.tracks);x.speed=o.speed;x.transpose=o.transpose;x.octave=o.octave;x.timbre=o.timbre;x.effect=o.effect;x.startSec=start;x.endSec=end;return x;}
    private static boolean relevant(Midi.Note n,Converter.Options o){return o.tracks.contains(n.track)&&n.channel!=9;}
    private static boolean held(Midi m,Converter.Options o,double sec){double t=sec*1000;for(Midi.Note n:m.notes)if(relevant(n,o)&&n.startMs<t-.00001&&n.endMs>t+.00001)return true;return false;}
    public static Plan plan(Midi midi,Converter.Options o){
        Plan p=new Plan();double cursor=o.startSec,end=o.endSec>0?o.endSec:midi.durationMs/1000;
        if(!Double.isFinite(cursor)||!Double.isFinite(end)||cursor<0||end<=cursor||end>midi.durationMs/1000+.001){p.errors.add("起止范围无效，请检查后重新规划");return p;}
        // Sweep ends before starts at equal timestamps, so a change between
        // adjacent notes is a safe boundary even without a written rest.
        TreeMap<Double,int[]> endpoints=new TreeMap<>();
        for(Midi.Note n:midi.notes)if(relevant(n,o)&&n.endMs>n.startMs){endpoints.computeIfAbsent(n.startMs/1000,k->new int[2])[0]++;endpoints.computeIfAbsent(n.endMs/1000,k->new int[2])[1]++;}
        NavigableSet<Double> natural=new TreeSet<>(),noteEnds=new TreeSet<>();int active=0;
        for(Map.Entry<Double,int[]> e:endpoints.entrySet()){active-=e.getValue()[1];if(e.getValue()[1]>0){noteEnds.add(e.getKey());if(active==0)natural.add(e.getKey());}active+=e.getValue()[0];}
        while(cursor<end-.000001){
            if(p.parts.size()>=128){p.errors.add("建议分段超过 128 段，请缩小起止范围再规划");break;}
            Converter.Result remaining=Converter.convert(midi,copy(o,cursor,end));
            if(remaining.ready()){p.parts.add(new Part(cursor,end,remaining,held(midi,o,cursor),held(midi,o,end)));cursor=end;break;}
            if(!remaining.capacityExceeded||remaining.errors.size()!=1){p.errors.addAll(remaining.errors);break;}
            // First capacity emitted entries estimate the search horizon only.
            // Never treat this prefix as a valid independently uploaded part.
            int units=0;for(int i=0;i<o.capacity;i++)units+=remaining.entries.get(i).units;
            double horizon=Math.min(end,cursor+units*.01*o.speed);
            Converter.Result chosen=null;double cut=0;
            // Prefer later safe cuts. If none fit, a note-ending cut with
            // other voices held is explicitly shown for user review.
            for(NavigableSet<Double> tier:Arrays.asList(natural,noteEnds)){
                int attempts=0;
                for(double candidate:tier.headSet(horizon+.000001,true).descendingSet()){
                    if(candidate<=cursor+.000001)break;
                    if(++attempts>64)break;
                    Converter.Result r=Converter.convert(midi,copy(o,cursor,candidate));
                    if(r.ready()){cut=candidate;chosen=r;break;}
                }
                if(chosen!=null)break;
            }
            if(chosen==null){p.errors.add("找不到经转换验证可容纳的音符结束断点。请手动缩小范围；不会直接截断事件列表。");break;}
            p.parts.add(new Part(cursor,cut,chosen,held(midi,o,cursor),held(midi,o,cut)));cursor=cut;
        }
        if(!p.errors.isEmpty())p.parts.clear();
        else {
            // Avoid a near-full first part followed by a handful of events.
            // Moving a boundary is accepted only after BOTH sides reconvert.
            for(int i=0;i+1<p.parts.size();i++){
                Part left=p.parts.get(i),right=p.parts.get(i+1);
                int oldMin=Math.min(left.result.entries.size(),right.result.entries.size());
                if(oldMin*2>=Math.max(left.result.entries.size(),right.result.entries.size()))continue;
                Converter.Result combined=Converter.convert(midi,copy(o,left.startSec,right.endSec));
                if(combined.entries.isEmpty())continue;
                int halfUnits=0;for(int j=0;j<combined.entries.size()/2;j++)halfUnits+=combined.entries.get(j).units;
                final double middle=left.startSec+halfUnits*.01*o.speed;
                boolean replaced=false;
                for(NavigableSet<Double> tier:Arrays.asList(natural,noteEnds)){
                    List<Double> candidates=new ArrayList<>(tier.subSet(left.startSec,false,right.endSec,false));
                    candidates.sort(Comparator.comparingDouble(t->Math.abs(t-middle)));
                    for(int j=0;j<Math.min(64,candidates.size());j++){
                        double at=candidates.get(j);
                        Converter.Result a=Converter.convert(midi,copy(o,left.startSec,at)),b=Converter.convert(midi,copy(o,at,right.endSec));
                        if(a.ready()&&b.ready()&&Math.min(a.entries.size(),b.entries.size())>oldMin){
                            p.parts.set(i,new Part(left.startSec,at,a,held(midi,o,left.startSec),held(midi,o,at)));
                            p.parts.set(i+1,new Part(at,right.endSec,b,held(midi,o,at),held(midi,o,right.endSec)));
                            replaced=true;break;
                        }
                    }
                    if(replaced)break;
                }
            }
        }
        return p;
    }
}
