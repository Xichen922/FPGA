package cn.b42.music;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Standard MIDI format 0/1 reader. All tracks share the merged tempo map. */
public final class Midi {
    public static final class Note {
        public int id, track, channel, pitch, velocity;
        public double startMs, endMs;
        public Note(int id,int track,int channel,int pitch,int velocity,double start,double end){
            this.id=id;this.track=track;this.channel=channel;this.pitch=pitch;this.velocity=velocity;startMs=start;endMs=end;
        }
    }
    public static final class Track {public String name; public int count;public boolean percussionOnly=true;}
    public final List<Note> notes=new ArrayList<>();
    public final List<Track> tracks=new ArrayList<>();
    public final Set<String> warnings=new LinkedHashSet<>();
    public double durationMs;
    private static final class Event {long tick;int order,track,status,a,b;Event(long t,int o,int tr,int s,int a,int b){tick=t;order=o;track=tr;status=s;this.a=a;this.b=b;}}
    private static final class Cursor {
        final byte[] b;int p,end;Cursor(byte[] b,int start,int end){this.b=b;p=start;this.end=end;}
        int u() throws IOException {if(p>=end)throw new IOException("MIDI 数据被截断");return b[p++]&255;}
        int n(int k)throws IOException{int x=0;while(k-->0)x=(x<<8)|u();return x;}
        int vlq()throws IOException{int x=0;for(int i=0;i<4;i++){int v=u();x=(x<<7)|(v&127);if(v<128)return x;}throw new IOException("MIDI 可变长度字段超过四字节");}
        void skip(int n)throws IOException{if(n<0||n>end-p)throw new IOException("MIDI 字段越界");p+=n;}
        String text(int n)throws IOException{if(n<0||n>end-p)throw new IOException("MIDI 文本越界");String s=new String(b,p,n,StandardCharsets.UTF_8).replace('\u0000',' ').trim();p+=n;return s;}
    }
    public static Midi read(byte[] bytes)throws IOException{
        if(bytes.length>20*1024*1024)throw new IOException("MIDI 超过 20 MB");
        Cursor c=new Cursor(bytes,0,bytes.length);
        if(c.n(4)!=0x4d546864)throw new IOException("不是标准 MIDI 文件（缺少 MThd）");
        int hl=c.n(4);if(hl<6||hl>bytes.length-8)throw new IOException("MIDI 头长度错误");
        int format=c.n(2),nt=c.n(2),division=c.n(2);c.skip(hl-6);
        if(format>1)throw new IOException("暂不支持异步多曲 MIDI 格式 2");
        if(nt<1||nt>512||(format==0&&nt!=1))throw new IOException("MIDI 轨道数量错误或超过 512");
        if(division==0||(division&0x8000)!=0)throw new IOException("第一版只支持 PPQ 时间制，不支持 SMPTE 时间制");
        Midi m=new Midi();List<Event> ev=new ArrayList<>();int order=0;long lastTick=0;
        for(int tr=0;tr<nt;tr++){
            if(c.n(4)!=0x4d54726b)throw new IOException("MIDI 缺少 MTrk 轨道块");
            int size=c.n(4);if(size<0||size>c.end-c.p)throw new IOException("MIDI 轨道长度错误");
            Cursor t=new Cursor(bytes,c.p,c.p+size);c.skip(size);Track track=new Track();track.name="轨道 "+(tr+1);m.tracks.add(track);
            long tick=0;int running=0;
            while(t.p<t.end){
                tick+=t.vlq();if(tick>0x7fffffffL)throw new IOException("MIDI 时间轴过长");lastTick=Math.max(lastTick,tick);
                int s=t.u();if(s<128){if(running==0)throw new IOException("MIDI 运行状态缺失");t.p--;s=running;}
                else if(s<0xf0)running=s;
                if(s==0xff){int type=t.u(),len=t.vlq();if(type==0x51){if(len!=3)throw new IOException("速度事件长度错误");int tempo=t.n(3);if(tempo==0)throw new IOException("MIDI 速度不能为零");ev.add(new Event(tick,order++,tr,0xff,tempo,0));}
                    else if(type==3)track.name=t.text(len);else t.skip(len);
                    if(type==0x2f)break;
                }else if(s==0xf0||s==0xf7){running=0;t.skip(t.vlq());}
                else if(s>=0xf0)throw new IOException("不支持的 MIDI 系统事件");
                else {int a=t.u(),b=((s&0xf0)==0xc0||(s&0xf0)==0xd0)?0:t.u();if(a>127||b>127)throw new IOException("MIDI 数据字节无效");
                    ev.add(new Event(tick,order++,tr,s,a,b));}
                if(ev.size()>1000000)throw new IOException("MIDI 事件过多");
            }
        }
        ev.sort(Comparator.comparingLong((Event e)->e.tick).thenComparingInt(e->e.order));
        // Pair by track/channel/key; sustain is applied to released notes per track/channel.
        Map<Integer,ArrayDeque<Note>> held=new HashMap<>();Map<Integer,List<Note>> sustained=new HashMap<>();Set<Integer> pedal=new HashSet<>();
        long tick=0;double ms=0;int tempo=500000,id=0;
        for(Event e:ev){ms+=(e.tick-tick)*(tempo/1000.0)/division;tick=e.tick;
            if(e.status==0xff){tempo=e.a;continue;}int type=e.status&0xf0,ch=e.status&15,tc=e.track*16+ch,key=tc*128+e.a;
            if(type==0x90&&e.b>0){Note n=new Note(id++,e.track,ch,e.a,e.b,ms,ms);held.computeIfAbsent(key,k->new ArrayDeque<>()).add(n);m.notes.add(n);Track tr=m.tracks.get(e.track);tr.count++;if(ch!=9)tr.percussionOnly=false;}
            else if(type==0x80||(type==0x90&&e.b==0)){ArrayDeque<Note> q=held.get(key);if(q!=null&&!q.isEmpty()){Note n=q.remove();if(pedal.contains(tc))sustained.computeIfAbsent(tc,k->new ArrayList<>()).add(n);else n.endMs=ms;}}
            else if(type==0xb0&&e.a==64){if(e.b>=64)pedal.add(tc);else {pedal.remove(tc);for(Note n:sustained.getOrDefault(tc,Collections.emptyList()))n.endMs=ms;sustained.remove(tc);}}
            else if(type==0xb0&&(e.a==120||e.a==123)){for(Map.Entry<Integer,ArrayDeque<Note>> q:held.entrySet())if(q.getKey()/128==tc){for(Note n:q.getValue())n.endMs=ms;q.getValue().clear();}for(Note n:sustained.getOrDefault(tc,Collections.emptyList()))n.endMs=ms;sustained.remove(tc);}
            else if(type==0xe0)m.warnings.add("含弯音：板端曲谱不能表达连续弯音，按原始音高转换");
        }
        ms+=(lastTick-tick)*(tempo/1000.0)/division;
        boolean dangling=false;for(ArrayDeque<Note> q:held.values())for(Note n:q){n.endMs=ms;dangling=true;}
        for(List<Note> q:sustained.values())for(Note n:q)n.endMs=ms;
        if(dangling)m.warnings.add("存在未配对的松键事件，已在 MIDI 结尾释放");
        for(Note n:m.notes)m.durationMs=Math.max(m.durationMs,n.endMs);
        if(m.notes.isEmpty())throw new IOException("文件中没有可转换的音符");
        return m;
    }
}
