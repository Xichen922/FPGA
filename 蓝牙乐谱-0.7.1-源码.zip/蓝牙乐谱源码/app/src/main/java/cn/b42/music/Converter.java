package cn.b42.music;

import java.util.*;

/** Deterministic absolute-time scheduler. B42 permits one onset octave group per tick. */
public final class Converter {
    public static final class Options {
        public Set<Integer> tracks=new HashSet<>(); public double speed=1,startSec=0,endSec=0;
        public int transpose=0,octave=-1,timbre=-1,effect=-1,capacity=512;
    }
    public static final class Result {
        public final List<Score.Entry> entries=new ArrayList<>();public final List<String> warnings=new ArrayList<>(),errors=new ArrayList<>();
        public int selectedNotes,simplified,delayed,retriggers,capacity=512;public boolean capacityExceeded;public boolean ready(){return errors.isEmpty()&&!entries.isEmpty()&&entries.size()<=capacity;}
    }
    private static final class N {int id,p,start,end;N(int id,int p,int s,int e){this.id=id;this.p=p;start=s;end=e;}}
    public static Result convert(Midi m,Options o){
        Result r=new Result();r.capacity=o.capacity;r.warnings.addAll(m.warnings);if(o.capacity!=512&&o.capacity!=8192){r.errors.add("不支持的板端容量，请连接识别固件后重试");return r;}
        if(o.tracks.isEmpty()){r.errors.add("请至少选择一条旋律轨道");return r;}
        if(o.speed<0.25||o.speed>3||o.transpose< -48||o.transpose>48){r.errors.add("速度须为 25%—300%，移调须为 -48—48 半音");return r;}
        double end=o.endSec>0?o.endSec*1000:m.durationMs,start=o.startSec*1000;
        if(start<0||end<=start||end>m.durationMs+1){r.errors.add("截取范围无效，请检查开始和结束秒数");return r;}
        int total=(int)Math.round((end-start)/(10*o.speed));if(total<1||total>180000){r.errors.add("转换后片段须为 0.01 秒—30 分钟");return r;}
        Map<Integer,List<N>> starts=new HashMap<>(),ends=new HashMap<>();int out=0,shorts=0,drums=0;
        for(Midi.Note n:m.notes){if(!o.tracks.contains(n.track)||n.endMs<=start||n.startMs>=end)continue;r.selectedNotes++;if(n.channel==9){drums++;continue;}
            int p=n.pitch+o.transpose;if(p<48||p>83){out++;continue;}if(o.octave>=3)p=(o.octave+1)*12+p%12;
            int a=(int)Math.round((Math.max(start,n.startMs)-start)/(10*o.speed));int b=(int)Math.round((Math.min(end,n.endMs)-start)/(10*o.speed));
            if(b<=a){shorts++;continue;}N v=new N(n.id,p,a,b);starts.computeIfAbsent(a,k->new ArrayList<>()).add(v);ends.computeIfAbsent(b,k->new ArrayList<>()).add(v);
        }
        if(out>0)r.errors.add(out+" 个音超出 C3—B5，请移调或截取后重试");
        if(shorts>0)r.errors.add(shorts+" 个音短于 10 ms 量化分辨率，请降低速度或换轨道");
        if(drums>0)r.warnings.add("已排除 "+drums+" 个打击乐通道音符（不能映射为旋律键）");
        if(o.octave>=3)r.warnings.add("已启用固定音区：所有音按音级映射到所选音区，原八度会改变");
        if(!r.errors.isEmpty())return r;
        @SuppressWarnings("unchecked") List<N>[] active=new List[12];for(int k=0;k<12;k++)active[k]=new ArrayList<>();
        N[] held=new N[12];int[] blockedUntil=new int[12];Set<Integer> simplified=new HashSet<>(),delayed=new HashSet<>(),desiredIds=new HashSet<>(),playedIds=new HashSet<>();
        int prevMask=-1,prevO=4,run=0;boolean poly=false;
        for(int tick=0;tick<total;tick++){
            for(N n:ends.getOrDefault(tick,Collections.emptyList()))active[n.p%12].remove(n);
            for(N n:starts.getOrDefault(tick,Collections.emptyList()))active[n.p%12].add(n);
            N[] target=new N[12];int simultaneous=0;
            for(int k=0;k<12;k++){
                for(N n:active[k])if(target[k]==null||n.p>target[k].p||(n.p==target[k].p&&n.start>target[k].start))target[k]=n;
                if(target[k]!=null){desiredIds.add(target[k].id);simultaneous++;for(N n:active[k])if(n!=target[k])simplified.add(n.id);}
                if(held[k]!=null&&(target[k]==null||held[k].id!=target[k].id)){
                    // A merged key must actually go low before any replacement/repeated attack.
                    held[k]=null;blockedUntil[k]=tick+2;if(target[k]!=null)r.retriggers++;
                }
            }
            poly|=simultaneous>1;
            int chosen=-1; // Reuse the current octave first, otherwise prioritize the upper group.
            for(int k=0;k<12;k++)if(held[k]==null&&target[k]!=null&&tick>=blockedUntil[k]){
                int oct=target[k].p/12-1;if(oct==prevO){chosen=oct;break;}chosen=Math.max(chosen,oct);
            }
            if(chosen<0)chosen=prevO;
            int mask=0;
            for(int k=0;k<12;k++){
                if(held[k]==null&&target[k]!=null&&tick>=blockedUntil[k]&&target[k].p/12-1==chosen){held[k]=target[k];playedIds.add(target[k].id);if(tick>target[k].start)delayed.add(target[k].id);}
                if(held[k]!=null)mask|=1<<k;
            }
            if(mask==prevMask&&chosen==prevO&&run<999)run++;
            else {if(run>0)r.entries.add(new Score.Entry(prevMask,run,prevO,o.timbre,o.effect));prevMask=mask;prevO=chosen;run=1;}
        }
        if(run>0)r.entries.add(new Score.Entry(prevMask,run,prevO,o.timbre,o.effect));
        desiredIds.removeAll(playedIds);if(!desiredIds.isEmpty())r.errors.add(desiredIds.size()+" 个音无法在原时间段内完成分组/重触发，请降低速度或改选轨道");
        r.simplified=simplified.size();r.delayed=delayed.size();
        if(r.simplified>0)r.warnings.add("同键冲突简化涉及 "+r.simplified+" 个音：优先保留较高音，同音高优先最新起音");
        if(r.delayed>0)r.warnings.add(r.delayed+" 个音因跨音区分组或重复击键延后起音；按原时间轴结束，不额外延长整段");
        if(r.retriggers>0)r.warnings.add("已安排 "+r.retriggers+" 次单键松开，重触发间隔至少 20 ms，其他键保持");
        if(poly)r.warnings.add("当前为复音转换；同拍跨音区分组至少错开 10 ms，并非严格同时起音");
        if(r.entries.size()>o.capacity){r.capacityExceeded=true;r.errors.add("转换后 "+r.entries.size()+" 条事件，超过 "+o.capacity+" 条，请选择较短片段");}
        if(r.entries.isEmpty()||playedIds.isEmpty())r.errors.add("选定范围内没有可演奏的旋律音符");
        return r;
    }
}
