package cn.b42.music;
import java.util.*;
/** Prefer explicit voice labels, not number of notes (accompaniment may be dense). */
public final class TrackSelection {
    public static boolean melody(String name){String n=name.toLowerCase(Locale.ROOT);return n.contains("melody")||n.contains("主旋律")||n.contains("旋律");}
    public static boolean accompaniment(String name){String n=name.toLowerCase(Locale.ROOT);return n.contains("accomp")||n.contains("伴奏")||n.contains("bass")||n.contains("低音");}
    public static int recommend(Midi m){
        for(int i=0;i<m.tracks.size();i++){Midi.Track t=m.tracks.get(i);if(t.count>0&&!t.percussionOnly&&melody(t.name)&&!accompaniment(t.name))return i;}
        for(Midi.Track t:m.tracks)if(melody(t.name)&&!accompaniment(t.name))return -1; // Explicit melody exists but is empty: never substitute the accompaniment.
        int best=-1,max=-1;for(int i=0;i<m.tracks.size();i++){Midi.Track t=m.tracks.get(i);if(t.count>max&&t.count>0&&!t.percussionOnly&&!accompaniment(t.name)){best=i;max=t.count;}}
        if(best>=0)return best;for(int i=0;i<m.tracks.size();i++)if(m.tracks.get(i).count>0&&!m.tracks.get(i).percussionOnly)return i;return -1;
    }
}
