package cn.b42.music;

import android.bluetooth.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.*;

final class BluetoothLink implements Session.Link {
    private final BluetoothSocket socket;
    private final BlockingQueue<String> lines=new LinkedBlockingQueue<>(128);
    private volatile IOException failure;
    private volatile boolean closed;
    static BluetoothLink connect(BluetoothDevice device)throws IOException{
        BluetoothSocket s=device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
        ScheduledExecutorService timeout=Executors.newSingleThreadScheduledExecutor();
        ScheduledFuture<?> f=timeout.schedule(()->{try{s.close();}catch(IOException ignored){}},15,TimeUnit.SECONDS);
        try{s.connect();return new BluetoothLink(s);}catch(IOException e){try{s.close();}catch(IOException ignored){}throw e;}finally{f.cancel(false);timeout.shutdownNow();}
    }
    BluetoothLink(BluetoothSocket s)throws IOException{socket=s;InputStream in=s.getInputStream();Thread reader=new Thread(()->{
        try{ByteArrayOutputStream line=new ByteArrayOutputStream();int v;while((v=in.read())!=-1){if(v=='\r')continue;if(v=='\n'){if(line.size()>0&&!lines.offer(new String(line.toByteArray(),StandardCharsets.US_ASCII)))throw new IOException("串口回执队列溢出");line.reset();}else {if(v>127||line.size()>=128)throw new IOException("串口收到无效数据");line.write(v);}}throw new IOException("设备已断开连接");}
        catch(IOException e){if(!closed)failure=e;}
    },"B42-SPP-reader");reader.setDaemon(true);reader.start();}
    @Override public void write(String line)throws IOException{if(closed)throw new IOException("蓝牙已断开");if(failure!=null)throw failure;socket.getOutputStream().write(line.getBytes(StandardCharsets.US_ASCII));socket.getOutputStream().flush();}
    @Override public String read(long timeoutMs)throws IOException{long until=System.currentTimeMillis()+timeoutMs;while(System.currentTimeMillis()<until){if(failure!=null)throw failure;if(closed)throw new IOException("蓝牙已断开");try{String s=lines.poll(Math.min(100,Math.max(1,until-System.currentTimeMillis())),TimeUnit.MILLISECONDS);if(s!=null)return s;}catch(InterruptedException e){Thread.currentThread().interrupt();throw new InterruptedIOException("收发已取消");}}return null;}
    IOException failure(){return failure;}
    @Override public void close(){closed=true;try{socket.close();}catch(IOException ignored){}}
}
