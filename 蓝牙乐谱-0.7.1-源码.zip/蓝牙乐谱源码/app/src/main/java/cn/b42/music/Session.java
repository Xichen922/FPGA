package cn.b42.music;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** One caller/queue owns this state machine. Never retry an uncertain append. */
public final class Session {
    public static final class GuideUnsupportedException extends IOException {
        public GuideUnsupportedException(){this(false);}
        public GuideUnsupportedException(boolean simple){super(simple?"当前 B 板不支持简单跟弹，需要队友升级支持 H 命令的配套固件。曲谱与连接保留；可手动选择正常模式重新跟弹。":"需要 B44 辅助演奏固件；当前固件不支持正常跟弹。曲谱已上传，可选择普通自动播放。");}
    }
    public interface Link {void write(String line)throws IOException;String read(long timeoutMs)throws IOException;void close();}
    public interface Progress {void changed(int done,int total);default void stage(String text){}}
    private final Link link;
    public final AtomicBoolean cancel=new AtomicBoolean();
    public boolean verified,uploaded;
    private ProtocolProfile profile=ProtocolProfile.LEGACY;
    public ProtocolProfile profile(){return profile;}
    public static final class StorageFailureException extends IOException {public StorageFailureException(){super("闪存擦除、写入或读回核验失败（X）。已停止上传；请检查供电、共地和接线，重新连接后从清空全量上传。");}}
    public Session(Link link){this.link=link;}
    public void verify()throws IOException{verified=false;uploaded=false;link.write("V\n");profile=ProtocolProfile.fromReply(response(3500));verified=true;}
    private String response(long timeout)throws IOException{String s=link.read(timeout);if(s==null)throw new IOException("等待板端回复超时");switch(s){case "X":throw new StorageFailureException();case "E":throw new IOException("板端拒绝：指令格式错误");case "F":throw new IOException("板端曲谱容量已满，上限 "+profile.capacity+" 条");case "B":throw new IOException("板端正忙或曲谱未初始化，已停止发送，请重新清空上传");case "Z":throw new IOException("板端曲谱为空");default:return s;}}
    private void expect(String wanted,long ms)throws IOException{String s=response(ms);if(!wanted.equals(s))throw new IOException("板端回复不符合预期："+s+"；需要 "+wanted);}
    private void ack(String s)throws IOException{ack(s,profile.eventTimeoutMs);}
    private void ack(String s,long timeout)throws IOException{link.write(s);expect("K",timeout);}
    public int query()throws IOException{link.write("?\n");return profile.count(response(profile.eventTimeoutMs));}
    public void stop()throws IOException{ack("S\n");}
    public void play()throws IOException{if(!verified||!uploaded)throw new IOException("请先连接匹配固件并成功上传当前曲谱");ack("P\n");}
    public void guide()throws IOException{guide(false);}
    public void guide(boolean simple)throws IOException{if(!verified||!uploaded)throw new IOException("请先成功上传当前曲谱");link.write(simple?"H\n":"G\n");String s=link.read(profile.eventTimeoutMs);if("E".equals(s))throw new GuideUnsupportedException(simple);if("X".equals(s))throw new StorageFailureException();if("Z".equals(s))throw new IOException("板端曲谱为空，请重新上传");if(!"K".equals(s))throw new IOException(s==null?"等待跟弹确认超时":"跟弹回复异常："+s);}
    public void invalidate(){uploaded=false;}
    public void uploadAndPlay(List<Score.Entry> entries,Progress p)throws IOException{
        upload(entries,p,false);
    }
    public void uploadAndGuide(List<Score.Entry> entries,Progress p)throws IOException{
        upload(entries,p,true);
    }
    public void uploadAndGuide(List<Score.Entry> entries,Progress p,boolean simple)throws IOException{
        upload(entries,p,true,simple);
    }
    private void upload(List<Score.Entry> entries,Progress p,boolean guideMode)throws IOException{
        upload(entries,p,guideMode,false);
    }
    private void upload(List<Score.Entry> entries,Progress p,boolean guideMode,boolean simple)throws IOException{
        if(!verified)throw new IOException("尚未确认新版 B42 固件");
        if(entries.isEmpty()||entries.size()>profile.capacity)throw new IOException("当前协议曲谱须为 1—"+profile.capacity+" 条");
        uploaded=false;cancel.set(false);int sent=0;
        try{
            p.stage("正在停止板端演奏 / 跟弹…");ack("S\n");p.stage(profile==ProtocolProfile.FLASH48?"正在擦除 Flash，等待完成确认（最长 20 秒）…":"正在清空板端曲谱…");ack("C\n",profile.clearTimeoutMs);if(query()!=0)throw new IOException("清空后数量不为零");p.stage(profile==ProtocolProfile.FLASH48?"开始逐条写入闪存并等待读回核验…":"开始逐条上传…");
            for(Score.Entry e:entries){if(cancel.get()){ack("S\n");throw new InterruptedIOException("上传已取消；板端仅保存部分曲谱，请重新上传");}ack(e.line());p.changed(++sent,entries.size());}
            if(cancel.get()){ack("S\n");throw new InterruptedIOException("上传已取消");}
            int actual=query();if(actual!=entries.size())throw new IOException("数量校验失败：期望 "+entries.size()+"，实际 "+actual);
            if(cancel.get()){ack("S\n");throw new InterruptedIOException("已取消播放");}
            uploaded=true;if(guideMode)guide(simple);else ack("P\n");
            if(cancel.get()){ack("S\n");throw new InterruptedIOException("已取消启动");}
        }catch(GuideUnsupportedException e){throw e;
        }catch(StorageFailureException e){uploaded=false;verified=false;link.close();throw e;
        }catch(InterruptedIOException e){uploaded=false;throw e;}
        catch(IOException e){
            // A delayed K might belong to an earlier append. Query diagnostically,
            // then close; reconnect + clear is the only restart path.
            String count="未知";
            try{link.write("?\n");long deadline=System.currentTimeMillis()+profile.eventTimeoutMs;while(System.currentTimeMillis()<deadline){String s=link.read(Math.max(1,deadline-System.currentTimeMillis()));if(s==null)break;try{count=Integer.toString(profile.count(s));break;}catch(IOException ignored){}}}catch(IOException ignored){}
            uploaded=false;verified=false;link.close();
            throw new IOException(e.getMessage()+"。板端数量="+count+"；已停止发送并断开。重新连接后从清空开始上传",e);
        }
    }
}
