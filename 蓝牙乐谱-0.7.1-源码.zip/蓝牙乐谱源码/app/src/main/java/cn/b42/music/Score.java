package cn.b42.music;

import java.util.*;

/** Protocol encoding lives here, never in views. Time is in 10 ms units. */
public final class Score {
    public static final int LIMIT=512,MAX_CAPACITY=8192;
    public static final class Entry {
        public final int mask,units,octave,timbre,effect;public final String legacy;
        public Entry(int m,int d,int o,int t,int e){this(m,d,o,t,e,null);}
        private Entry(int m,int d,int o,int t,int e,String l){if(m<0||m>4095||d<1||d>999||o< -1||o>5||(o!=-1&&o<3)||t< -1||t>3||e< -1||e>2)throw new IllegalArgumentException("曲谱字段越界");mask=m;units=d;octave=o;timbre=t;effect=e;legacy=l;}
        static String f(int x){return x<0?"-":Integer.toString(x);}
        public String line(){return legacy!=null?legacy+"\n":String.format(Locale.ROOT,"M%03X,%03d,%s,%s,%s\n",mask,units,f(octave),f(timbre),f(effect));}
    }
    public static List<Entry> parseAscii(String text){List<Entry> r=new ArrayList<>();for(String raw:text.split("\r?\n")){String s=raw.trim();if(s.isEmpty()||s.equals("C")||s.equals("?")||s.equals("P"))continue;
        if(!s.matches("(?:M[0-9A-Fa-f]{3}|(?:0[0-9]|1[0-2])),[0-9]{3}(?:,[345-],[0-3-],[0-2-])?"))throw new IllegalArgumentException("测试曲谱格式错误："+s);
        String[] a=s.split(",");boolean mask=a[0].startsWith("M");int v=Integer.parseInt(mask?a[0].substring(1):a[0],mask?16:10);int d=Integer.parseInt(a[1]);int o=a.length>2?parseField(a[2]):-1,t=a.length>2?parseField(a[3]):-1,e=a.length>2?parseField(a[4]):-1;
        r.add(new Entry(mask?v:v==0?0:1<<(v-1),d,o,t,e,mask?null:s));}
        if(r.isEmpty()||r.size()>MAX_CAPACITY)throw new IllegalArgumentException("测试曲谱须为 1—8192 条（实际上传上限按固件版本）");return r;}
    private static int parseField(String s){return s.equals("-")?-1:Integer.parseInt(s);}
    public static double seconds(List<Entry> entries){double ms=0;boolean te=false,oe=false;int ot=-1,oo=-1,oldmask=0;for(Entry e:entries){boolean timbre=e.timbre>=0&&(!te||ot!=e.timbre);boolean octave=(oe!=(e.octave>=0)||(e.octave>=0&&oo!=e.octave))&&((e.mask&~oldmask)!=0);ms+=e.units*10;if(timbre)ms+=10;else if(e.legacy!=null&&octave)ms+=3;te=e.timbre>=0;oe=e.octave>=0;ot=e.timbre;oo=e.octave;oldmask=e.mask;}return ms/1000;}
}
