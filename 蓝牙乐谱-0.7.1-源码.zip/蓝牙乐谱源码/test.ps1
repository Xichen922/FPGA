param([Parameter(Mandatory=$true)][string]$JavaHome,[string]$TestDir=(Join-Path $PSScriptRoot 'test-build'))
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Path $TestDir -Force | Out-Null
$core=Join-Path $PSScriptRoot 'app\src\main\java\cn\b42\music'
$sources=@('Midi.java','Score.java','Converter.java','Session.java','TaskFailurePolicy.java','TrackSelection.java','SegmentPlanner.java','ProtocolProfile.java')|ForEach-Object{Join-Path $core $_}
& (Join-Path $JavaHome 'bin\javac.exe') --release 8 -Xlint:-options -encoding UTF-8 -d $TestDir @sources (Join-Path $PSScriptRoot 'tests\CoreTest.java') (Join-Path $PSScriptRoot 'tests\GuideTest.java') (Join-Path $PSScriptRoot 'tests\MidiPackTest.java') (Join-Path $PSScriptRoot 'tests\VoiceTest.java') (Join-Path $PSScriptRoot 'tests\SegmentTest.java') (Join-Path $PSScriptRoot 'tests\Flash48Test.java')
if($LASTEXITCODE -ne 0){throw 'Test compilation failed'}
$fixtures=@((Join-Path $PSScriptRoot 'app\src\main\assets\huanzhou.txt'))
$sample=Join-Path $PSScriptRoot 'tests\跨音区测试.mid'
if(Test-Path -LiteralPath $sample){$fixtures+=$sample}
& (Join-Path $JavaHome 'bin\java.exe') '-Dstdout.encoding=UTF-8' -cp $TestDir cn.b42.music.CoreTest @fixtures
if($LASTEXITCODE -ne 0){throw 'Core tests failed'}
& (Join-Path $JavaHome 'bin\java.exe') '-Dstdout.encoding=UTF-8' -cp $TestDir cn.b42.music.GuideTest
if($LASTEXITCODE -ne 0){throw 'Guide tests failed'}

& (Join-Path $JavaHome 'bin\java.exe') '-Dstdout.encoding=UTF-8' -cp $TestDir cn.b42.music.VoiceTest (Join-Path $PSScriptRoot 'tests\midi44') (Join-Path $PSScriptRoot 'tests\voices') (Join-Path $PSScriptRoot 'tests\voices\不染_前4小节_对谱校正_统一降八度.mid')
if($LASTEXITCODE -ne 0){throw 'Voice tests failed'}

& (Join-Path $JavaHome 'bin\java.exe') '-Dstdout.encoding=UTF-8' -cp $TestDir cn.b42.music.SegmentTest (Join-Path $PSScriptRoot 'tests\midi44\不染_旋律_适配C3-B5.mid')
if($LASTEXITCODE -ne 0){throw 'Segment tests failed'}

& (Join-Path $JavaHome 'bin\java.exe') '-Dstdout.encoding=UTF-8' -cp $TestDir cn.b42.music.Flash48Test (Join-Path $PSScriptRoot 'tests\midi44\不染_旋律_适配C3-B5.mid')
if($LASTEXITCODE -ne 0){throw 'Flash48 tests failed'}
