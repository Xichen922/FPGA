# 蓝牙乐谱 0.7.1

2026-10-31 构建交付：电脑直传可读取 `X-Midi-Name` 中的 UTF-8 编码曲名；旧服务缺少曲名时仍使用默认名称。已修复接收回调漏分号及 build_local.ps1 的旧版文件名，成功生成 APK。原有核心测试、曲名处理检查、资源及签名校验通过；电脑与手机实机联调待验证。详见 `电脑直传_0.7.1_曲名说明.md` 与 `0.7.1构建验证记录.md`。

Android 离线 HC-06/B42/B44 曲谱 App，Java 原生界面，无第三方运行时依赖。交付的是供实机联调的测试版本。

0.2.0 新增 G 跟弹上传/重练/S 停止、旧固件 G=E 兼容提示，以及 55 个适配 MIDI 的内置曲库。跟弹时不按时间推算进度。详见中文使用说明.md。版本号 2，继续使用旧版同一签名。原 42 项核心检查与 12 项跟弹检查均通过。

## 0.3.0 更改

修复 Windows 打包反斜杠资源名导致 Android 无法读取曲库的问题；本地文件异常不再断开无关蓝牙连接。新增简单/正常选择，简单 H 命令需配套 B 板，当前 B44 返回 E 时保留连接并提示更新。65 项逻辑断言通过，实际 APK 全部资源另由 tests/verify_apk_assets.py 校验。详见中文使用说明.md 与 B板简单跟弹接口.md。

## 功能与固件

- Android 8.0（API 26）起可安装；目标 SDK 35，纯 Java/Dex，无 CPU 架构限制。本次没有手机或模拟器运行记录，实际机型兼容性待验证。
- 对接用户提供的 example42(3).zip 协议，连接后必须得到 V=042；配套 A37 需有逐键触发时锁存音区的能力。
- MIDI 0/1、多轨选择、全局速度变化、休止、延音踏板解析；PPQ 时间制。格式 2、SMPTE 时间制明确拒绝。
- 曲库保存导入原文件副本、原 URI、曲名、转换参数、转换后的协议文本。重新打开曲目恢复参数，再点击转换检查；不会把断线前的板端曲谱当作已经可靠上传的当前曲目。
- B42 按键快照、同音区和弦、跨音区分组、新音延后与 20 ms 同键重触发、长音拆分、512 条上限检查、片段选择。
- 串行上传状态机，逐条 ACK，上传前清空，核对数量后播放。回执异常/超时不盲目重发；查询仅用于诊断，随后断开，重连并清空重新上传。
- 从头重播、停止、取消上传、数量查询、估计进度；内置《幻昼》旧格式 415 条回归数据及跨音区联调序列。

## 目录

- `app/src/main/java/cn/b42/music/Midi.java`：标准 MIDI 解析，保留轨道、起止、音高、力度与通道。
- `Converter.java`：时间轴、冲突选择、分组和松键调度；独立于 Android。
- `Score.java`：统一 B42 编码、旧测试数据读取、预计时长。
- `Session.java`：纯 Java 协议状态机，可替换 Link 接口测试。
- `BluetoothLink.java`：SPP 连接、独立读线程和行回执队列。
- `MainActivity.java`：中文界面、系统文件选择器、曲库和参数保存。
- `tests/CoreTest.java`、`test.ps1`：42 项核心断言，包含 MIDI 人工构造数据、交付的跨音区 MIDI 和用户提供的《幻昼》数据。
- `app/src/main/assets/`：用户提供的《幻昼》测试文本与自建跨音区测试文本；不含音频录音。

## 已验证的构建方式（Windows PowerShell）

准备 JDK 17 或以上（本次使用本机已有 OpenJDK 21）、Android Platform 35 的 android.jar，以及 SDK Build-Tools 36.0.0。依赖必须先安装/下载，构建脚本本身不下载依赖。

```powershell
.\test.ps1 -JavaHome 'C:\tools\jdk-21' -TestDir 'C:\build\b42-tests'
.\build.ps1 -JavaHome 'C:\tools\jdk-21' `
  -BuildTools 'C:\Android\Sdk\build-tools\36.0.0' `
  -AndroidJar 'C:\Android\Sdk\platforms\android-35\android.jar' `
  -BuildDir 'C:\build\b42'
```

Windows aapt2 对非 ASCII 路径兼容性有限，因此 BuildDir 必须为纯英文路径；脚本会自动把中文源码目录中的文件复制到该构建目录再编译。输出为 BluetoothScore-0.7.1.apk。

本次实际通过该脚本完成 javac → D8 → aapt2 → zipalign → apksigner 构建；v2/v3 签名校验通过。脚本使用源代码包内 test-signing.jks（别名 b42test，测试密码 android），这是方便本地联调和同签名更新的公开测试签名，不是发布凭据。

另提供 Android Studio/Gradle 项目配置：AGP 8.9.2，Gradle 8.11.1，JDK 17+。该路径未在本次环境运行，且不附带 Gradle wrapper；可用匹配版本 Gradle 或 Android Studio 打开。若用另一签名安装，将不能覆盖当前 APK，需保持同一签名或卸载后再安装；卸载会清除本地曲库。

## 转换规则

1. 将所有轨道的速度事件合并为真实毫秒时间，按所选轨道生成音符起止；速度百分比缩放后，绝对起止时间四舍五入到 10 ms。
2. 默认保留 C3—B5 原始音高。移调后仍超范围则阻止上传；固定音区选项会改变原八度，界面会提示。打击乐通道 10 排除并提示；弯音不能表达，转换时提示。
3. 同一音级冲突优先较高音；同音高重叠优先较新起音。仅简化冲突声部，其他和弦键保留。被压制的旧音若之后仍持续，可在高优先音结束后重新触发；结果提示简化涉及的音符数量。
4. 同一时刻只能加入一个新音区组。优先当前音区组，其余组逐个 10 ms 时间槽加入；事件总长度保留原时间轴，不在尾部追加额外时间。B 板对音区切换的约 3 ms 预备包含在事件内；实际起音误差除分组时间外还受 SPI 轮询影响。
5. 每个键独立安排至少 20 ms 松键后再触发，不松开其他持续键。结束时间沿用原时间轴，因此重触发音的起音可能延后、发声时间缩短。
6. 如果某个应演奏音因分组/重触发没有时间实际起音，或量化后时长为零，阻止上传，建议降速、改选轨道或截取。不会声称已完整演奏这些音。
7. 长时间段按最多 999 个单位拆分；保持相同按键快照，不为长音人为重触发。统计拆分、休止、分组及松键事件后的最终数量。
8. 音色/音效整首固定为所选设置，或跟随实体控制。进度为估计值；切换音色时的 10 ms 额外等待按已知板端规则计入估算，不能代替设备实际状态。

## 官方参考

- [Android 蓝牙权限](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)：只连接已配对设备，Android 12+ 申请 BLUETOOTH_CONNECT，不做扫描。
- [经典蓝牙连接](https://developer.android.com/develop/connectivity/bluetooth/connect-bluetooth-devices)：使用 RFCOMM/SPP socket，耗时连接和收发在后台执行。
- [系统文件选择器](https://developer.android.com/training/data-storage/shared/documents-files)：导入文件后复制到应用私有目录，不申请整个存储空间权限。
- [AGP 8.9 兼容性](https://developer.android.com/build/releases/agp-8-9-0-release-notes)：备用 Android Studio 构建配置依据。

## 尚待验证

手机启动/布局/权限流程、OPPO Find X8 与其他手机兼容性、真实 HC-06 收发、A37+B42 双板听音、断线重连、板端同键间隔及起音时序、giselle.mid（仍未提供）；本次新包 69 个 MIDI 已完成离线解析与适配版转换检查。本项目不包含固件修改或烧录。

## 0.4.0 声部与源谱排查

优先显式 Melody 主旋律，空主旋律不回退伴奏。增加只听主旋律/原音高复位与显式合奏按钮。旧内置曲库声部选择首次迁移为旋律，保留其他参数；用户可点击复位。内置原谱标待复核，新增不染前4小节对谱校正且整体降12半音样例。原 MIDI 本身的八度/时值错误不能靠解码器自动修正。详见中文使用说明.md。

## 0.5.0 自动分段

新增 SegmentPlanner，按事件计数生成完整源时间分区，优先全松边界，再考虑音符结束边界，并明确持续音重新起音。每段独立转换、重新核对512上限，尾段过短时验证两侧后平衡断点。UI提供范围/数量预览、选择、下一段；手动逐段上传。参数变化清除计划。新增65项分段断言，详见中文使用说明.md。

## 0.6.0 B48 Flash 适配

ProtocolProfile 通过 V=042/V=048 决定 512/8192、三/四位计数和超时。Converter.Options.capacity、Result.capacity 与 SegmentPlanner 贯穿同一容量。B48 清空20s、事件3.5s，X存储失败立即关闭不确定连接，丢回执不重发。上传状态明确显示擦除与逐条确认。原有常量512仅作旧协议默认/离线保守配置，MIDI轨道数保护与板端事件容量无关。详见中文使用说明.md。
